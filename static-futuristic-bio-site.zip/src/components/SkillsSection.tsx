export function SkillsSection() {
  const skills = [
    { name: 'React / Next.js', level: 92, color: '#00f0ff' },
    { name: 'TypeScript', level: 88, color: '#a855f7' },
    { name: 'Node.js', level: 85, color: '#00ff88' },
    { name: 'Python', level: 78, color: '#ec4899' },
    { name: 'UI/UX Design', level: 90, color: '#00f0ff' },
    { name: 'DevOps / Cloud', level: 72, color: '#a855f7' },
  ];

  const tools = [
    'VS Code', 'Figma', 'Docker', 'AWS', 'Git', 'Linux',
    'MongoDB', 'PostgreSQL', 'Redis', 'GraphQL', 'Tailwind', 'Three.js'
  ];

  return (
    <section id="skills" className="relative py-32 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Section label */}
        <div className="flex items-center gap-4 mb-12">
          <span className="font-[family-name:var(--font-family-mono)] text-[11px] text-cyber-purple/60 tracking-[0.4em] uppercase">
            // skill_matrix
          </span>
          <div className="flex-1 h-[1px] bg-gradient-to-r from-cyber-purple/20 to-transparent" />
        </div>

        {/* Skill bars */}
        <div className="space-y-6 mb-16">
          {skills.map((skill) => (
            <div key={skill.name} className="group">
              <div className="flex justify-between items-center mb-2">
                <span className="font-[family-name:var(--font-family-inter)] text-sm text-white/60 group-hover:text-white/90 transition-colors">
                  {skill.name}
                </span>
                <span className="font-[family-name:var(--font-family-mono)] text-xs" style={{ color: skill.color }}>
                  {skill.level}%
                </span>
              </div>
              <div className="h-1.5 bg-dark-card rounded-full overflow-hidden border border-dark-border">
                <div
                  className="h-full rounded-full transition-all duration-1000 relative"
                  style={{
                    width: `${skill.level}%`,
                    background: `linear-gradient(90deg, ${skill.color}44, ${skill.color})`,
                    boxShadow: `0 0 10px ${skill.color}44`,
                  }}
                >
                  <div
                    className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full"
                    style={{ backgroundColor: skill.color, boxShadow: `0 0 8px ${skill.color}` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Tools grid */}
        <div>
          <h3 className="font-[family-name:var(--font-family-mono)] text-[11px] text-white/30 tracking-[0.3em] uppercase mb-6">
            Tools & Technologies
          </h3>
          <div className="flex flex-wrap gap-3">
            {tools.map((tool) => (
              <span
                key={tool}
                className="px-4 py-2 rounded-lg border border-dark-border bg-dark-card/30 font-[family-name:var(--font-family-mono)] text-xs text-white/40 hover:text-cyber-blue hover:border-cyber-blue/30 transition-all duration-300 cursor-default"
              >
                {tool}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
