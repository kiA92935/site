export function ProjectsSection() {
  const projects = [
    {
      title: 'NeoChat',
      description: 'Real-time messaging platform with AI-powered responses and end-to-end encryption.',
      tags: ['React', 'Node.js', 'WebSocket', 'AI'],
      color: '#00f0ff',
      icon: '💬',
    },
    {
      title: 'QuantumDash',
      description: 'Analytics dashboard with real-time data visualization and predictive insights.',
      tags: ['Next.js', 'D3.js', 'Python', 'ML'],
      color: '#a855f7',
      icon: '📊',
    },
    {
      title: 'CyberVault',
      description: 'Decentralized file storage with zero-knowledge encryption and seamless sharing.',
      tags: ['TypeScript', 'IPFS', 'Solidity', 'Web3'],
      color: '#ec4899',
      icon: '🔐',
    },
    {
      title: 'SynthWave',
      description: 'Generative music platform using AI to create unique ambient soundscapes.',
      tags: ['React', 'Web Audio', 'TensorFlow', 'Canvas'],
      color: '#00ff88',
      icon: '🎵',
    },
  ];

  return (
    <section id="projects" className="relative py-32 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Section label */}
        <div className="flex items-center gap-4 mb-12">
          <span className="font-[family-name:var(--font-family-mono)] text-[11px] text-cyber-pink/60 tracking-[0.4em] uppercase">
            // featured_projects
          </span>
          <div className="flex-1 h-[1px] bg-gradient-to-r from-cyber-pink/20 to-transparent" />
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {projects.map((project) => (
            <div
              key={project.title}
              className="group relative p-6 rounded-2xl border border-dark-border bg-dark-card/30 backdrop-blur-sm hover:border-opacity-50 transition-all duration-500 cursor-pointer overflow-hidden"
              style={{ '--project-color': project.color } as React.CSSProperties}
            >
              {/* Hover glow */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl"
                style={{ boxShadow: `inset 0 0 40px ${project.color}08, 0 0 20px ${project.color}08` }}
              />

              {/* Top accent line */}
              <div
                className="absolute top-0 left-6 right-6 h-[1px] opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{ background: `linear-gradient(90deg, transparent, ${project.color}66, transparent)` }}
              />

              <div className="relative z-10">
                {/* Icon & Title */}
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <span className="text-2xl mb-2 block">{project.icon}</span>
                    <h3 className="font-[family-name:var(--font-family-orbitron)] text-lg font-semibold text-white group-hover:text-opacity-100 transition-colors">
                      {project.title}
                    </h3>
                  </div>
                  <svg
                    className="w-5 h-5 text-white/10 group-hover:text-white/40 transition-all duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                    fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 19.5l15-15m0 0H8.25m11.25 0v11.25" />
                  </svg>
                </div>

                {/* Description */}
                <p className="font-[family-name:var(--font-family-inter)] text-sm text-white/30 leading-relaxed mb-5">
                  {project.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 rounded-md font-[family-name:var(--font-family-mono)] text-[10px] tracking-wider uppercase border"
                      style={{
                        color: `${project.color}88`,
                        borderColor: `${project.color}20`,
                        backgroundColor: `${project.color}08`,
                      }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
