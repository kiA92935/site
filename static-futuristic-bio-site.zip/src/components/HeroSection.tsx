import { useState, useEffect } from 'react';

export function HeroSection() {
  const [statusText, setStatusText] = useState('');
  const fullText = 'SYSTEM ONLINE — ALL NODES ACTIVE';

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      setStatusText(fullText.slice(0, i + 1));
      i++;
      if (i >= fullText.length) clearInterval(interval);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center px-6">
      {/* Radial glow behind avatar */}
      <div className="absolute w-[600px] h-[600px] rounded-full bg-cyber-blue/5 blur-[120px] pointer-events-none" />
      <div className="absolute w-[400px] h-[400px] rounded-full bg-cyber-purple/5 blur-[100px] pointer-events-none translate-x-32 translate-y-16" />

      <div className="relative z-10 text-center max-w-3xl">
        {/* Avatar */}
        <div className="animate-fade-in-up delay-100 mb-8 flex justify-center">
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-cyber-blue/20 animate-pulse-ring" />
            <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-cyber-blue via-cyber-purple to-cyber-pink p-[2px]">
              <div className="w-full h-full rounded-full bg-dark-bg" />
            </div>
            <div className="relative w-28 h-28 rounded-full bg-gradient-to-br from-dark-card to-dark-bg border-2 border-cyber-blue/30 flex items-center justify-center animate-float overflow-hidden">
              <span className="text-4xl">🚀</span>
            </div>
          </div>
        </div>

        {/* Name */}
        <h1 className="animate-fade-in-up delay-200 font-[family-name:var(--font-family-orbitron)] text-5xl md:text-7xl font-bold tracking-wider mb-4">
          <span className="bg-gradient-to-r from-cyber-blue via-white to-cyber-purple bg-clip-text text-transparent">
            YOUR NAME
          </span>
        </h1>

        {/* Tagline */}
        <p className="animate-fade-in-up delay-300 font-[family-name:var(--font-family-inter)] text-lg md:text-xl text-white/50 font-light tracking-wide mb-6">
          Full-Stack Developer · Designer · Digital Creator
        </p>

        {/* Status bar */}
        <div className="animate-fade-in-up delay-400 inline-flex items-center gap-3 px-5 py-2.5 rounded-full border border-cyber-green/20 bg-cyber-green/5">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyber-green opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyber-green" />
          </span>
          <span className="font-[family-name:var(--font-family-mono)] text-xs text-cyber-green/80 tracking-widest cursor-blink">
            {statusText}
          </span>
        </div>

        {/* Scroll indicator */}
        <div className="animate-fade-in-up delay-600 mt-16">
          <div className="flex flex-col items-center gap-2 text-white/20">
            <span className="font-[family-name:var(--font-family-mono)] text-[10px] tracking-[0.3em] uppercase">Scroll</span>
            <div className="w-[1px] h-8 bg-gradient-to-b from-white/20 to-transparent animate-pulse" />
          </div>
        </div>
      </div>
    </section>
  );
}
