export function AboutSection() {
  const stats = [
    { label: 'YEARS EXP', value: '5+', color: 'cyber-blue' },
    { label: 'PROJECTS', value: '30+', color: 'cyber-purple' },
    { label: 'CLIENTS', value: '20+', color: 'cyber-pink' },
    { label: 'COFFEES', value: '∞', color: 'cyber-green' },
  ];

  return (
    <section id="about" className="relative py-32 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Section label */}
        <div className="flex items-center gap-4 mb-12">
          <span className="font-[family-name:var(--font-family-mono)] text-[11px] text-cyber-blue/60 tracking-[0.4em] uppercase">
            // about_me
          </span>
          <div className="flex-1 h-[1px] bg-gradient-to-r from-cyber-blue/20 to-transparent" />
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Text block */}
          <div className="space-y-6">
            <h2 className="font-[family-name:var(--font-family-orbitron)] text-2xl md:text-3xl font-semibold text-white glow-text">
              Building the Future,<br />
              <span className="text-cyber-purple">One Line at a Time</span>
            </h2>
            <p className="font-[family-name:var(--font-family-inter)] text-white/40 leading-relaxed text-sm">
              I'm a passionate developer and designer who thrives at the intersection of 
              technology and creativity. I craft digital experiences that are not just functional, 
              but memorable. From sleek interfaces to robust backends, I bring ideas to life 
              with clean code and pixel-perfect design.
            </p>
            <p className="font-[family-name:var(--font-family-inter)] text-white/40 leading-relaxed text-sm">
              When I'm not coding, you'll find me exploring emerging tech, contributing to 
              open-source projects, or designing futuristic UI concepts that push boundaries.
            </p>
          </div>

          {/* Stats grid */}
          <div className="grid grid-cols-2 gap-4">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="group relative p-6 rounded-xl border border-dark-border bg-dark-card/50 hover:border-cyber-blue/30 transition-all duration-500 hover:glow-border"
              >
                <div className={`font-[family-name:var(--font-family-orbitron)] text-3xl font-bold text-${stat.color} mb-2`}>
                  {stat.value}
                </div>
                <div className="font-[family-name:var(--font-family-mono)] text-[10px] tracking-[0.3em] text-white/30 uppercase">
                  {stat.label}
                </div>
                <div className={`absolute top-0 right-0 w-8 h-8 border-t border-r border-${stat.color}/20 rounded-tr-xl`} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
