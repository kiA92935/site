export function Footer() {
  return (
    <footer className="relative py-12 px-6 border-t border-dark-border">
      <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="font-[family-name:var(--font-family-mono)] text-[10px] text-white/15 tracking-[0.3em] uppercase">
          Designed & Built with 💜
        </div>
        <div className="font-[family-name:var(--font-family-mono)] text-[10px] text-white/15 tracking-wider">
          © {new Date().getFullYear()} — YOUR NAME. All rights reserved.
        </div>
        <div className="font-[family-name:var(--font-family-mono)] text-[10px] text-white/10 tracking-wider">
          v1.0.0
        </div>
      </div>
    </footer>
  );
}
