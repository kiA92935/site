import { Navbar } from './components/Navbar';
import { ParticleField } from './components/ParticleField';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { SkillsSection } from './components/SkillsSection';
import { ProjectsSection } from './components/ProjectsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

export function App() {
  return (
    <div className="relative min-h-screen bg-dark-bg text-white grid-bg scanline">
      {/* Noise overlay */}
      <div className="noise-overlay" />

      {/* Particle background */}
      <ParticleField />

      {/* Navigation */}
      <Navbar />

      {/* Main content */}
      <main className="relative z-10">
        <HeroSection />

        {/* Divider */}
        <div className="max-w-4xl mx-auto px-6">
          <div className="h-[1px] bg-gradient-to-r from-transparent via-dark-border to-transparent" />
        </div>

        <AboutSection />

        <div className="max-w-4xl mx-auto px-6">
          <div className="h-[1px] bg-gradient-to-r from-transparent via-dark-border to-transparent" />
        </div>

        <SkillsSection />

        <div className="max-w-4xl mx-auto px-6">
          <div className="h-[1px] bg-gradient-to-r from-transparent via-dark-border to-transparent" />
        </div>

        <ProjectsSection />

        <div className="max-w-4xl mx-auto px-6">
          <div className="h-[1px] bg-gradient-to-r from-transparent via-dark-border to-transparent" />
        </div>

        <ContactSection />
      </main>

      <Footer />
    </div>
  );
}
